import csv
import os
import re
import uuid
from datetime import date, datetime
import tkinter as tk
from tkinter import messagebox, ttk


SPECIALTIES = {
    "Терапевт": ["Иванов Иван Иванович", "Петрова Анна Сергеевна"],
    "Кардиолог": ["Сидоров Алексей Павлович", "Ким Елена Викторовна"],
    "Невролог": ["Ахметов Данияр Ерланович", "Смирнова Ольга Игоревна"],
    "Педиатр": ["Кузнецова Мария Андреевна", "Омаров Руслан Нурланович"],
    "Офтальмолог": ["Васильева Ирина Петровна", "Нуртаев Алишер Маратович"],
}
TIMES = [f"{hour:02d}:00" for hour in range(9, 18)]
STATUSES = ["Запланирован", "Пациент принят", "Отменён", "Пациент не явился"]
CSV_FIELDS = [
    "id", "last_name", "first_name", "middle_name", "iin", "birth_date",
    "phone", "email", "doctor", "specialty", "appointment_date",
    "appointment_time", "visit_type", "format", "complaints", "status",
]


class AppointmentApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Запись на приём к врачу")
        self.root.geometry("1250x760")
        self.root.minsize(750, 550)
        self.csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "appointments.csv")
        self.appointments = []
        self.editing_id = None

        self._build_ui()
        self.load_data()
        self.refresh_table()

    def _build_ui(self):
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        form = ttk.LabelFrame(self.root, text="Данные пациента и приёма", padding=8)
        form.grid(row=0, column=0, sticky="ew", padx=8, pady=6)
        for column in range(8):
            form.columnconfigure(column, weight=1)

        self.patient_vars = {
            key: tk.StringVar()
            for key in ("last_name", "first_name", "middle_name", "iin", "birth_date", "phone", "email")
        }
        fields = [
            ("Фамилия", "last_name", 0, 0), ("Имя", "first_name", 0, 2),
            ("Отчество", "middle_name", 0, 4), ("ИИН (12 цифр)", "iin", 1, 0),
            ("Дата рождения (ДД.ММ.ГГГГ)", "birth_date", 1, 2),
            ("Телефон", "phone", 1, 4), ("Электронная почта", "email", 2, 0),
        ]
        for label, key, row, col in fields:
            ttk.Label(form, text=label).grid(row=row, column=col, sticky="w", padx=4, pady=3)
            entry = ttk.Entry(form, textvariable=self.patient_vars[key])
            entry.grid(row=row, column=col + 1, sticky="ew", padx=4, pady=3)

        ttk.Label(form, text="Специальность").grid(row=2, column=2, sticky="w", padx=4)
        self.specialty_var = tk.StringVar()
        self.specialty_box = ttk.Combobox(
            form, textvariable=self.specialty_var, values=list(SPECIALTIES), state="readonly"
        )
        self.specialty_box.grid(row=2, column=3, sticky="ew", padx=4, pady=3)
        self.specialty_box.bind("<<ComboboxSelected>>", self._update_doctors)

        ttk.Label(form, text="Врач").grid(row=2, column=4, sticky="w", padx=4)
        self.doctor_var = tk.StringVar()
        self.doctor_box = ttk.Combobox(form, textvariable=self.doctor_var, state="readonly")
        self.doctor_box.grid(row=2, column=5, sticky="ew", padx=4, pady=3)
        self.specialty_box.current(0)
        self._update_doctors()

        ttk.Label(form, text="Дата приёма (ДД.ММ.ГГГГ)").grid(row=3, column=0, sticky="w", padx=4)
        self.appointment_date_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.appointment_date_var).grid(
            row=3, column=1, sticky="ew", padx=4, pady=3
        )
        ttk.Label(form, text="Время").grid(row=3, column=2, sticky="w", padx=4)
        self.time_var = tk.StringVar()
        ttk.Combobox(form, textvariable=self.time_var, values=TIMES, state="readonly").grid(
            row=3, column=3, sticky="ew", padx=4, pady=3
        )

        visit_frame = ttk.LabelFrame(form, text="Тип приёма")
        visit_frame.grid(row=3, column=4, sticky="ew", padx=4, pady=2)
        self.visit_type_var = tk.StringVar(value="Первичный")
        for value in ("Первичный", "Повторный"):
            ttk.Radiobutton(visit_frame, text=value, variable=self.visit_type_var, value=value).pack(side="left")

        format_frame = ttk.LabelFrame(form, text="Формат")
        format_frame.grid(row=3, column=5, sticky="ew", padx=4, pady=2)
        self.format_var = tk.StringVar(value="Очный")
        for value in ("Очный", "Онлайн"):
            ttk.Radiobutton(format_frame, text=value, variable=self.format_var, value=value).pack(side="left")

        ttk.Label(form, text="Жалобы (не более 300 символов)").grid(
            row=4, column=0, sticky="nw", padx=4, pady=3
        )
        self.complaints = tk.Text(form, height=3, width=50, wrap="word")
        self.complaints.grid(row=4, column=1, columnspan=4, sticky="ew", padx=4, pady=3)
        self.complaints.bind("<<Modified>>", self._limit_complaints)
        self.complaints_count = ttk.Label(form, text="0 / 300")
        self.complaints_count.grid(row=4, column=5, sticky="ne", padx=4)

        actions = ttk.Frame(form)
        actions.grid(row=5, column=0, columnspan=6, sticky="ew", pady=(5, 0))
        self.submit_button = ttk.Button(actions, text="Записаться на приём", command=self.add_appointment)
        self.submit_button.pack(side="left", padx=3)
        ttk.Button(actions, text="Очистить форму", command=self.clear_form).pack(side="left", padx=3)

        records = ttk.LabelFrame(self.root, text="Записи на приём", padding=8)
        records.grid(row=1, column=0, sticky="nsew", padx=8, pady=6)
        records.columnconfigure(0, weight=1)
        records.rowconfigure(1, weight=1)

        filters = ttk.Frame(records)
        filters.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(filters, text="Ф. И. О.").pack(side="left")
        self.search_name_var = tk.StringVar()
        name_entry = ttk.Entry(filters, textvariable=self.search_name_var, width=18)
        name_entry.pack(side="left", padx=(3, 8))
        name_entry.bind("<KeyRelease>", lambda _event: self.refresh_table())
        ttk.Label(filters, text="ИИН").pack(side="left")
        self.search_iin_var = tk.StringVar()
        iin_entry = ttk.Entry(filters, textvariable=self.search_iin_var, width=14)
        iin_entry.pack(side="left", padx=(3, 8))
        iin_entry.bind("<KeyRelease>", lambda _event: self.refresh_table())
        ttk.Label(filters, text="Врач").pack(side="left")
        self.filter_doctor_var = tk.StringVar(value="Все")
        doctors = sorted({doctor for names in SPECIALTIES.values() for doctor in names})
        doctor_filter = ttk.Combobox(
            filters, textvariable=self.filter_doctor_var, values=["Все"] + doctors, state="readonly", width=22
        )
        doctor_filter.pack(side="left", padx=3)
        doctor_filter.bind("<<ComboboxSelected>>", lambda _event: self.refresh_table())
        ttk.Label(filters, text="Дата").pack(side="left")
        self.filter_date_var = tk.StringVar()
        date_filter = ttk.Entry(filters, textvariable=self.filter_date_var, width=12)
        date_filter.pack(side="left", padx=3)
        date_filter.bind("<KeyRelease>", lambda _event: self.refresh_table())
        ttk.Label(filters, text="Статус").pack(side="left")
        self.filter_status_var = tk.StringVar(value="Все")
        status_filter = ttk.Combobox(
            filters, textvariable=self.filter_status_var, values=["Все"] + STATUSES, state="readonly", width=18
        )
        status_filter.pack(side="left", padx=3)
        status_filter.bind("<<ComboboxSelected>>", lambda _event: self.refresh_table())
        ttk.Button(filters, text="Показать все", command=self.reset_filters).pack(side="left", padx=4)

        columns = ("patient", "doctor", "specialty", "date", "time", "format", "status")
        self.tree = ttk.Treeview(records, columns=columns, show="headings", selectmode="browse")
        headings = {
            "patient": ("Пациент", 165), "doctor": ("Врач", 190), "specialty": ("Специальность", 120),
            "date": ("Дата", 95), "time": ("Время", 65), "format": ("Формат", 80), "status": ("Статус", 135),
        }
        for column, (title, width) in headings.items():
            self.tree.heading(column, text=title)
            self.tree.column(column, width=width, minwidth=55, anchor="w")
        self.tree.grid(row=1, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(records, orient="vertical", command=self.tree.yview)
        vertical.grid(row=1, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(records, orient="horizontal", command=self.tree.xview)
        horizontal.grid(row=2, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.tree.tag_configure("Запланирован", background="#fff4cc")
        self.tree.tag_configure("Пациент принят", background="#d9f2d9")
        self.tree.tag_configure("Отменён", background="#f5d6d6")
        self.tree.tag_configure("Пациент не явился", background="#e5ddf5")
        self.tree.bind("<Double-1>", lambda _event: self.show_details())

        management = ttk.Frame(records)
        management.grid(row=3, column=0, sticky="ew", pady=(6, 0))
        ttk.Button(management, text="Подробности", command=self.show_details).pack(side="left", padx=3)
        ttk.Button(management, text="Изменить запись", command=self.edit_appointment).pack(side="left", padx=3)
        ttk.Button(management, text="Изменить статус", command=self.change_status).pack(side="left", padx=3)
        ttk.Button(management, text="Отменить запись", command=self.cancel_appointment).pack(side="left", padx=3)
        ttk.Button(management, text="Удалить запись", command=self.delete_appointment).pack(side="left", padx=3)

    def _update_doctors(self, _event=None):
        doctors = SPECIALTIES.get(self.specialty_var.get(), [])
        self.doctor_box.configure(values=doctors)
        self.doctor_var.set(doctors[0] if doctors else "")

    def _limit_complaints(self, _event=None):
        if not self.complaints.edit_modified():
            return
        self.complaints.edit_modified(False)
        value = self.complaints.get("1.0", "end-1c")
        if len(value) > 300:
            self.complaints.delete("1.0 + 300 chars", "end-1c")
            value = self.complaints.get("1.0", "end-1c")
        self.complaints_count.configure(text=f"{len(value)} / 300")

    def validate_form(self):
        values = {key: var.get().strip() for key, var in self.patient_vars.items()}
        full_name = " ".join(values[key] for key in ("last_name", "first_name", "middle_name")).strip()
        if not values["last_name"] or not values["first_name"]:
            return None, "Введите фамилию и имя пациента."
        if not re.fullmatch(r"\d{12}", values["iin"]):
            return None, "ИИН должен содержать ровно 12 цифр."
        try:
            birth_date = datetime.strptime(values["birth_date"], "%d.%m.%Y").date()
            if birth_date > date.today():
                return None, "Дата рождения не может быть в будущем."
            age = date.today().year - birth_date.year - (
                (date.today().month, date.today().day) < (birth_date.month, birth_date.day)
            )
            if age < 0 or age > 120:
                return None, "Проверьте дату рождения пациента."
        except ValueError:
            return None, "Введите корректную дату рождения в формате ДД.ММ.ГГГГ."
        if not re.fullmatch(r"[0-9+()\-\s]{7,20}", values["phone"]) or sum(
            char.isdigit() for char in values["phone"]
        ) < 7:
            return None, "Телефон должен содержать допустимые символы и не менее 7 цифр."
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", values["email"]):
            return None, "Введите корректный адрес электронной почты."

        specialty = self.specialty_var.get()
        doctor = self.doctor_var.get()
        if specialty not in SPECIALTIES or doctor not in SPECIALTIES.get(specialty, []):
            return None, "Выберите специальность и врача."
        try:
            appointment_date = datetime.strptime(self.appointment_date_var.get().strip(), "%d.%m.%Y").date()
        except ValueError:
            return None, "Введите корректную дату приёма в формате ДД.ММ.ГГГГ."
        if appointment_date < date.today():
            return None, "Нельзя записаться на прошедшую дату."
        appointment_time = self.time_var.get()
        if appointment_time not in TIMES:
            return None, "Выберите время приёма."
        if appointment_date == date.today() and appointment_time <= datetime.now().strftime("%H:%M"):
            return None, "Выберите время, которое ещё не прошло."

        return {
            **values,
            "id": self.editing_id or str(uuid.uuid4()),
            "doctor": doctor,
            "specialty": specialty,
            "appointment_date": appointment_date.strftime("%d.%m.%Y"),
            "appointment_time": appointment_time,
            "visit_type": self.visit_type_var.get(),
            "format": self.format_var.get(),
            "complaints": self.complaints.get("1.0", "end-1c").strip(),
            "status": self._current_status(),
            "patient": full_name,
        }, None

    def _current_status(self):
        if self.editing_id:
            existing = next((item for item in self.appointments if item["id"] == self.editing_id), None)
            if existing:
                return existing.get("status", "Запланирован")
        return "Запланирован"

    def _has_conflict(self, record):
        return any(
            item["id"] != record["id"]
            and item.get("doctor") == record["doctor"]
            and item.get("appointment_date") == record["appointment_date"]
            and item.get("appointment_time") == record["appointment_time"]
            and item.get("status") != "Отменён"
            for item in self.appointments
        )

    def add_appointment(self):
        record, error = self.validate_form()
        if error:
            messagebox.showerror("Ошибка ввода", error, parent=self.root)
            return
        if self._has_conflict(record):
            messagebox.showwarning(
                "Время занято", "У этого врача уже есть запись на выбранные дату и время. Выберите другое свободное время.",
                parent=self.root,
            )
            return
        self.appointments.append(record)
        if not self.save_data():
            self.appointments.pop()
            return
        self.refresh_table()
        self.clear_form()
        messagebox.showinfo("Успешно", "Пациент записан на приём.", parent=self.root)

    def edit_appointment(self):
        selected = self._selected_record()
        if not selected:
            return
        self.editing_id = selected["id"]
        for key, var in self.patient_vars.items():
            var.set(selected.get(key, ""))
        self.specialty_var.set(selected.get("specialty", ""))
        self._update_doctors()
        self.doctor_var.set(selected.get("doctor", ""))
        self.appointment_date_var.set(selected.get("appointment_date", ""))
        self.time_var.set(selected.get("appointment_time", ""))
        self.visit_type_var.set(selected.get("visit_type", "Первичный"))
        self.format_var.set(selected.get("format", "Очный"))
        self.complaints.delete("1.0", "end")
        self.complaints.insert("1.0", selected.get("complaints", ""))
        self.submit_button.configure(text="Сохранить изменения", command=self.update_appointment)

    def update_appointment(self):
        record, error = self.validate_form()
        if error:
            messagebox.showerror("Ошибка ввода", error, parent=self.root)
            return
        if self._has_conflict(record):
            messagebox.showwarning(
                "Время занято", "У этого врача уже есть запись на выбранные дату и время. Выберите другое свободное время.",
                parent=self.root,
            )
            return
        index = next((i for i, item in enumerate(self.appointments) if item["id"] == self.editing_id), None)
        if index is None:
            messagebox.showerror("Ошибка", "Изменяемая запись не найдена.", parent=self.root)
            self.clear_form()
            return
        previous = self.appointments[index]
        self.appointments[index] = record
        if not self.save_data():
            self.appointments[index] = previous
            return
        self.refresh_table()
        self.clear_form()
        messagebox.showinfo("Успешно", "Изменения сохранены.", parent=self.root)

    def _selected_record(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Нет выбора", "Сначала выберите запись в таблице.", parent=self.root)
            return None
        record_id = selection[0]
        return next((item for item in self.appointments if item["id"] == record_id), None)

    def change_status(self):
        record = self._selected_record()
        if not record:
            return
        window = tk.Toplevel(self.root)
        window.title("Изменить статус")
        window.resizable(False, False)
        window.transient(self.root)
        window.grab_set()
        status_var = tk.StringVar(value=record.get("status", STATUSES[0]))
        ttk.Label(window, text="Выберите новый статус:").pack(padx=12, pady=(12, 4))
        combo = ttk.Combobox(window, textvariable=status_var, values=STATUSES, state="readonly")
        combo.pack(padx=12, pady=4)

        def save_status():
            old_status = record.get("status", STATUSES[0])
            record["status"] = status_var.get()
            if self.save_data():
                self.refresh_table()
                window.destroy()
            else:
                record["status"] = old_status

        ttk.Button(window, text="Сохранить", command=save_status).pack(pady=10)

    def cancel_appointment(self):
        record = self._selected_record()
        if not record:
            return
        if record.get("status") == "Отменён":
            messagebox.showinfo("Информация", "Эта запись уже отменена.", parent=self.root)
            return
        previous = record.get("status")
        record["status"] = "Отменён"
        if self.save_data():
            self.refresh_table()
        else:
            record["status"] = previous

    def delete_appointment(self):
        record = self._selected_record()
        if not record:
            return
        patient = self._patient_name(record)
        if not messagebox.askyesno(
            "Подтверждение удаления", f"Удалить запись пациента «{patient}»?", parent=self.root
        ):
            return
        index = self.appointments.index(record)
        self.appointments.pop(index)
        if not self.save_data():
            self.appointments.insert(index, record)
            return
        self.refresh_table()

    def show_details(self):
        record = self._selected_record()
        if not record:
            return
        details = [
            ("Пациент", self._patient_name(record)),
            ("ИИН", record.get("iin", "")),
            ("Дата рождения", record.get("birth_date", "")),
            ("Телефон", record.get("phone", "")),
            ("Электронная почта", record.get("email", "")),
            ("Врач", record.get("doctor", "")),
            ("Специальность", record.get("specialty", "")),
            ("Дата и время", f"{record.get('appointment_date', '')} {record.get('appointment_time', '')}"),
            ("Тип приёма", record.get("visit_type", "")),
            ("Формат", record.get("format", "")),
            ("Статус", record.get("status", "")),
            ("Жалобы", record.get("complaints", "") or "Не указаны"),
        ]
        window = tk.Toplevel(self.root)
        window.title("Подробности записи")
        window.transient(self.root)
        frame = ttk.Frame(window, padding=12)
        frame.pack(fill="both", expand=True)
        for row, (label, value) in enumerate(details):
            ttk.Label(frame, text=f"{label}:", font=("TkDefaultFont", 9, "bold")).grid(
                row=row, column=0, sticky="nw", padx=(0, 10), pady=3
            )
            ttk.Label(frame, text=value, wraplength=420, justify="left").grid(
                row=row, column=1, sticky="nw", pady=3
            )

    def refresh_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        name_query = self.search_name_var.get().strip().casefold()
        iin_query = self.search_iin_var.get().strip().casefold()
        doctor_query = self.filter_doctor_var.get()
        date_query = self.filter_date_var.get().strip()
        status_query = self.filter_status_var.get()
        for record in self.appointments:
            if name_query and name_query not in self._patient_name(record).casefold():
                continue
            if iin_query and iin_query not in record.get("iin", "").casefold():
                continue
            if doctor_query != "Все" and doctor_query != record.get("doctor"):
                continue
            if date_query and date_query not in record.get("appointment_date", ""):
                continue
            if status_query != "Все" and status_query != record.get("status"):
                continue
            self.tree.insert(
                "", "end", iid=record["id"],
                values=(
                    self._patient_name(record), record.get("doctor", ""), record.get("specialty", ""),
                    record.get("appointment_date", ""), record.get("appointment_time", ""),
                    record.get("format", ""), record.get("status", "Запланирован"),
                ),
                tags=(record.get("status", "Запланирован"),),
            )

    @staticmethod
    def _patient_name(record):
        return " ".join(
            part for part in (record.get("last_name", ""), record.get("first_name", ""), record.get("middle_name", ""))
            if part
        )

    def reset_filters(self):
        self.search_name_var.set("")
        self.search_iin_var.set("")
        self.filter_doctor_var.set("Все")
        self.filter_date_var.set("")
        self.filter_status_var.set("Все")
        self.refresh_table()

    def clear_form(self):
        for variable in self.patient_vars.values():
            variable.set("")
        self.specialty_box.current(0)
        self._update_doctors()
        self.appointment_date_var.set("")
        self.time_var.set("")
        self.visit_type_var.set("Первичный")
        self.format_var.set("Очный")
        self.complaints.delete("1.0", "end")
        self.editing_id = None
        self.submit_button.configure(text="Записаться на приём", command=self.add_appointment)

    def load_data(self):
        if not os.path.exists(self.csv_path):
            return
        try:
            with open(self.csv_path, "r", newline="", encoding="utf-8-sig") as file:
                for row in csv.DictReader(file):
                    if not row.get("id"):
                        row["id"] = str(uuid.uuid4())
                    row.setdefault("status", "Запланирован")
                    self.appointments.append({key: row.get(key, "") for key in CSV_FIELDS})
        except (OSError, csv.Error, UnicodeError) as error:
            messagebox.showerror("Ошибка загрузки", f"Не удалось прочитать файл записей:\n{error}", parent=self.root)

    def save_data(self):
        try:
            with open(self.csv_path, "w", newline="", encoding="utf-8-sig") as file:
                writer = csv.DictWriter(file, fieldnames=CSV_FIELDS, extrasaction="ignore")
                writer.writeheader()
                writer.writerows(self.appointments)
            return True
        except (OSError, csv.Error, UnicodeError) as error:
            messagebox.showerror("Ошибка сохранения", f"Не удалось сохранить записи:\n{error}", parent=self.root)
            return False


if __name__ == "__main__":
    root = tk.Tk()
    app = AppointmentApp(root)
    root.mainloop()
